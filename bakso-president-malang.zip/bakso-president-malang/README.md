# Bakso President Malang

## Project Overview
This project is a website for "Bakso President Malang," a legendary culinary destination in Malang, Indonesia. The website showcases the menu, history, and important information about the restaurant.

## Project Structure
```
bakso-president-malang
├── index.html          # Main HTML document for the website
├── css
│   ├── variables.css   # CSS variables for color palette
│   └── styles.css      # Main styles for the website
├── js
│   └── main.js         # JavaScript for interactive features
├── assets
│   ├── images          # Directory for image files
│   └── fonts           # Directory for custom font files
├── .gitignore          # Git ignore file
└── README.md           # Documentation for the project
```

## Color Palette
- **Bakso Brown**: #6f4c3e
- **Kuah Gold**: #d4af37
- **Chili Red**: #c2185b
- **Fresh Green**: #4caf50
- **Dark Gray**: #1a1a1a
- **Light Gray**: #f8f9fa

## Features
- Responsive design for mobile and desktop views.
- Smooth scrolling for navigation links.
- Interactive menu cards with hover effects.
- Information sections for location, operating hours, and contact details.

## Setup Instructions
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd bakso-president-malang
   ```
3. Open `index.html` in your web browser to view the website.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any suggestions or improvements.

## License
This project is licensed under the MIT License.