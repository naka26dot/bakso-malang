
// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Form submission
const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
        e.preventDefault();
        alert('Terima kasih telah menghubungi kami! Kami akan segera membalas pesan Anda.');
        this.reset();
    });
}

// Button hover effects
const buttons = document.querySelectorAll('.btn');
buttons.forEach(button => {
    button.addEventListener('mouseenter', function () {
        this.style.transform = 'translateY(-2px)';
    });
    button.addEventListener('mouseleave', function () {
        this.style.transform = 'translateY(0)';
    });
});

// scroll effect for header
window.addEventListener('scroll', function () {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

document.addEventListener("DOMContentLoaded", function () {
    fetch('data/menu.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(menuData => {
            generateMenuCards(menuData);
        })
        .catch(error => {
            console.error('Error saat mengambil data menu:', error);
            const menuGridContainer = document.querySelector('.menu-grid');
            menuGridContainer.innerHTML = '<p style="color: red; text-align: center;">Gagal memuat menu. Silakan coba lagi nanti.</p>';
        });

});

function generateMenuCards(menuData) {
    const menuGridContainer = document.querySelector('.menu-grid');
    let allMenuHTML = '';
    menuData.forEach(menu => {
        const cardHTML = `
            <div class="menu-card">
                <div class="menu-img" style="background-image: url('${menu.imageUrl}')"></div>
                <div class="menu-info">
                    <h3>${menu.title}</h3>
                    <p>${menu.description}</p>
                    <div class="menu-price">
                        <span class="price">${menu.price}</span>
                        <a href="#" class="btn">Pesan</a>
                    </div>
                </div>
            </div>
        `;
        allMenuHTML += cardHTML;
    });
    menuGridContainer.innerHTML = allMenuHTML;
}